//
//  RWTTile.h
//  CookieCrunch
//
//  Created by Matthijs on 26-02-14.
//  Copyright (c) 2014 Razeware LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RWTTile : NSObject

// Note: To support different types of tiles, you can add properties here that
// indicate how this tile should behave. For example, if a cookie is matched
// that sits on a jelly tile, you'd set isJelly to NO to make it a normal tile.
//@property (assign, nonatomic) BOOL isJelly;

@end
