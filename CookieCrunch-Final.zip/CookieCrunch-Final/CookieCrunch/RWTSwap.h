
@class RWTCookie;

@interface RWTSwap : NSObject

@property (strong, nonatomic) RWTCookie *cookieA;
@property (strong, nonatomic) RWTCookie *cookieB;

@end
