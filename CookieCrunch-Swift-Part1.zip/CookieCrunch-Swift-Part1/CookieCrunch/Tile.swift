//
//  Tile.swift
//  CookieCrunch
//
//  Created by Matthijs on 19-06-14.
//  Copyright (c) 2014 Razeware LLC. All rights reserved.
//

class Tile {
  // Note: To support different types of tiles, you can add properties here that
  // indicate how this tile should behave. 
  // For example, if a cookie is matched that sits on a jelly tile, you'd set
  // isJelly to false to make it a normal tile.
  //var isJelly: Bool
}
